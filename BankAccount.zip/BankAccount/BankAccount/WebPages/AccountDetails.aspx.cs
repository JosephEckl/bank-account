﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BankAccount.Classes;

namespace BankAccount.WebPages
{
    public partial class AccountDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["selection"] == null && Session["balance"] == null)
            {
                int i = (int)Session["index"];
                List<Account> selected = (List<Account>)Session["accounts"];
                Account selectedAccount = selected[i];
                Session.Add("selection", selectedAccount);

                double bal = selectedAccount.Balance;
                Session.Add("balance", bal);
            }

            Customer cus = (Customer)Session["customers"];

            Account selectedAcc = (Account)Session["selection"];
            double balance = (double)Session["balance"];

            accNameLabel.Text = selectedAcc.Nickname;
            accTypeLabel.Text = selectedAcc.Type;
            accBalanceLabel.Text = balance.ToString("C");
            loanLabel.Text = selectedAcc.HasLoanOffer().ToString();
            addressLabel.Text = cus.FullAddress;
        }

        protected void withdrawButton_Click(object sender, EventArgs e)
        {
            double balance = (double)Session["balance"];
            double withdraw = double.Parse(amountTextBox.Text);
            double output = balance - withdraw;

            if (withdraw > balance)
            {
                errorLabel.Text = "Withdraw amount greater than balance";
            }
            else
            {
                accBalanceLabel.Text = output.ToString("C");
                Session.Remove("balance");
                Session.Add("balance", output);
            }
        }
    }
}