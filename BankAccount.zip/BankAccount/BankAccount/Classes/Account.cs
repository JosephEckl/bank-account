﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BankAccount
{
    public class Account
    {
        private string _type;
        private double _balance;
        private string _nickname;

        public Account(string type, double balance, string nickname)
        {
            Type = type;
            Balance = balance;
            Nickname = nickname;
        }

        public string Type
        {
            get
            {
                return _type;
            }
            set
            {
                _type = value;
            }
        }

        public double Balance
        {
            get
            {
                return _balance;
            }
            set
            {
                _balance = value;
            }
        }

        public string Nickname
        {
            get
            {
                return _nickname;
            }
            set
            {
                _nickname = value;
            }
        }

        public bool HasLoanOffer()
        {
            if (Balance > 15000)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}