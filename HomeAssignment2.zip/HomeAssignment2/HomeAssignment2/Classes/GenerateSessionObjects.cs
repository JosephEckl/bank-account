﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HomeAssignment2.Classes
{
    public class GenerateSessionObjects
    {
        private List<Account> accountList = new List<Account>();

        public GenerateSessionObjects()
        {
            Account a1 = new Account("Checking", 25000, "Checking");
            Account a2 = new Account("Checking", 10000, "Reserve");
            Account a3 = new Account("Savings", 12000, "Savings");
            accountList.Add(a1);
            accountList.Add(a2);
            accountList.Add(a3);

            Customer c1 = new Customer("123 Street St.", "Example Name");

            HttpContext.Current.Session.Add("accounts", accountList);
            HttpContext.Current.Session.Add("customers", c1);
        }
    }
}