﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HomeAssignment2.Classes
{
    public class Customer
    {
        private string _fulladdress;
        private string _fullname;

        public Customer(string fullAddress, string fullName)
        {
            _fulladdress = fullAddress;
            _fullname = fullName;
        }

        public string FullAddress
        {
            get
            {
                return _fulladdress;
            }
        }

        public string FullName
        {
            get
            {
                return _fullname;
            }
        }
    }
}