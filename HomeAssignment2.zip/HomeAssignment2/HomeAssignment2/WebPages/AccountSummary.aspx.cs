﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HomeAssignment2.Classes;

namespace HomeAssignment2.WebPages
{
    public partial class AccountSummary : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GenerateSessionObjects sesObj = new GenerateSessionObjects();
                Customer cus = (Customer)Session["customers"];
                nameLabel.Text = cus.FullName;

                List<Account> accList = (List<Account>)Session["accounts"];
                foreach (Account a in accList)
                {
                    accountListBox.Items.Add(a.Nickname);
                }
            }
        }

        protected void detailsButton_Click(object sender, EventArgs e)
        {
            Session.Add("index", accountListBox.SelectedIndex);
            Server.Transfer("AccountDetails.aspx");
        }
    }
}