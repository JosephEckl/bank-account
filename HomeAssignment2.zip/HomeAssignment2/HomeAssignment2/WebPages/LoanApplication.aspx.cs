﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HomeAssignment2.Classes;

namespace HomeAssignment2.WebPages
{
    public partial class LoanApplication : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Customer cus = (Customer)Session["customers"];
            nameLabel.Text = cus.FullName;
        }

        protected void submitButton_Click(object sender, EventArgs e)
        {
            int age = int.Parse(ageTextBox.Text);
            double salary = double.Parse(salaryTextBox.Text);
            double loanamount = double.Parse(amountTextBox.Text);

            double balance = (double)Session["balance"];

            if(age > 18 && loanamount < balance && loanamount < 0.5 * salary)
            {
                approvalLabel.Text = "Approved";
            }
            else
            {
                approvalLabel.Text = "Declined";
            }
        }
    }
}